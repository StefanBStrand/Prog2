public class MoonGravity {
    public static void main(String[] args) {
        double weight = 95;
        double moonWeight = weight * 0.165;
        System.out.println("My weight on the moon is " + moonWeight + " kilograms");
    }
}

